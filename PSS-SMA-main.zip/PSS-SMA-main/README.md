# PSS + SMA
